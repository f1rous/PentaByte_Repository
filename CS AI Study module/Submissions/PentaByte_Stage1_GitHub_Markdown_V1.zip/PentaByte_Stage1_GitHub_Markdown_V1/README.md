
# Algorithms, Data Structures & Connectionist AI

> Stage 1 — GitHub Repository and Markdown Content V1.0

## About the Project

this projects main goal is to create beginner friendly content that is digestible for Noobs
it will mainly talk about definitions and cosepts

## Team Members

  |Username | IRL Names  | Student ID | Responsibility |
  |---|---|---|---|
  |MarvinT-prog | Marvin Tan 陈威宏 | 1820262139| Project Plan
  |F1rous | Elgin asokananda Theng 唐于钦 |1820262140| Repository and Markdown
  |swap-nil-07 |Swapnil Mondal 苏明 | 1820262094 | Personal logs and Module Outline
  |AroundTheWorld170672 | Nicholas Wirgatama 吳宜展 | 1820252090| Project Log and Summaries
  |HASAN MD RAKIB AL | RAKIB-DEV354 | 1820262062| Live Status Reports

## Learning Materials

| Section | Content | Status |
|---|---|---|
| Algorithms | Concepts, examples and complexity | In progress |
| Data Structures | Core structures and operations | In progress |
| Connectionist AI | Neurons and basic neural networks | In progress |

## Repository Guide

- `Docs/` — planning, outline and review records
- `Content/` — learning chapters in Markdown
- `Assets/` — diagrams, images and examples
- `Logs/` — AI-use and contribution records
- `Submission/` — report drafts and evidence

## Project Progress

**Current version:** V1.0  
**Last updated:** 2026-10-20

Completed:
- [ ] Repository and team setup
- [ ] Module outline
- [ ] Substantive learning content
- [ ] Peer review
- [ ] Verify references and examples
- [ ] Capture repository evidence
- [ ] Generate the readable content PDF
- [ ] Prepare and test the submission ZIP

## How to Use This Repository

Start with `content/index.md`, then follow the chapters in numerical
order. Check each lesson's status before treating it as reviewed.



